package com.example.database.ui.screens.components

class PostItem {
}
package com.example.database.data.local.entity

//Debemos de revisar que tenemos las dependencias necesarias correctamente
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")

//Paso 1

    //No se cuanto vaya a durar el video, en si es una base de datos
    //En android studio esto deberemos implementarlo a nuestro proyecto

data class PostEntity(
    //Nuestra llave primaria (Es la estructura de nuestra Base de Datos por tabla)
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val content: String
)